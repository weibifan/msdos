/*
	COW : Character Oriented Windows

	static.h : static cow private interface
*/

/* Static Text Styles */

#define SS_LEFT 		0	/* left justified text */
#define SS_CENTER 		1	/* centered text */
#define SS_RIGHT 		2	/* right justified text */


DWORD	FARPUBLIC	StaticWndProc(PWND, WORD, WORD, DWORD);

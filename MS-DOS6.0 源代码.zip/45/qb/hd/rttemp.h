/*** 
*rttemp.inc - temporary extern's and data struct's for shared runtime interface
*
*	Copyright <C> 1986, Microsoft Corporation
*
*Purpose:
*	This file is for temporary use only - - - a more complete set of
*	header files will be developed in conjunction with the runtime group.
*
*******************************************************************************/

#undef	RTTEMP_H
#define	RTTEMP_H	ON

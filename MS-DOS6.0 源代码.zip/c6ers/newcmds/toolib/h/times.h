/* times.h - format of time stamp */

#define STAMP	    "%2d:%02d:%02d %2d %3s %4d"
#define STAMPLEN    20

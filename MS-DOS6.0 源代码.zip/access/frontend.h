
   /* Start of Function Protocols */

void RedrawScreen(int helpMessageFlag);
void OutputHintBar(char *hintText, int justifyFlag, int helpMessageFlag);
void ClearDesktop(void);
void OutputTitleBar(void);

void ManageMenu(void);
int  PrintMenuBar(int currentMenu);
void PrintMenuList(int currentMenuList, int leftMargin);

   /* end of Function Protocols */

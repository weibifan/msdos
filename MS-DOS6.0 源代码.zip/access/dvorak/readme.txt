This directory has all files for compiling DVORAK.SYS file.

Run NMAKE (or XMSMAKE). After this rename keyboard.sys to DVORAK.SYS.

DVORAK.SYS includes following keyboard layouts:

1. Swiss-German
2. German
3. Italian
4. UK English
5. Polish
6. Czech
7. Slovak
8. Yugoslavian (Latin)
9. Hungarian
10. Romanian
11. US Dvorak
12. US right single-handed key
13. US left single-handed key

Notes:

1. Layouts 5-9 have some changes from US DOS 5.0.
2. Layouts 10-13 are new for US DOS 5.0

You should use standard KEYB.COM from US DOS 5.0.

All notes, bugs send to  Yuri Starikov (email: yst).




#ifndef LEVEL_PARSER_H
#define LEVEL_PARSER_H

#include "world.h"
#include "dosdefs.h"

#include <stdio.h>

struct level_parser
{
    const char *filename;
    unsigned curr_row;
    unsigned curr_col;
    FILE *fp;

    int box_count;
    int dock_count;
    int worker_count;

    bool done;
    bool parse_error;
    bool stopped;
};

void lp_init(struct level_parser *parser, const char *filename);
bool lp_open(struct level_parser *parser);
bool lp_next(struct level_parser *parser, struct world *world);
bool lp_stopped(struct level_parser *parser);
bool lp_close(struct level_parser *parser);

#endif

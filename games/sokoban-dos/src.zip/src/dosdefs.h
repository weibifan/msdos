#ifndef DOSDEFS_H
#define DOSDEFS_H

/* Turbo C 2.01 compatibility: stdbool.h not available */
#define bool  int
#define true  1
#define false 0
#define TRUE  1
#define FALSE 0

#endif

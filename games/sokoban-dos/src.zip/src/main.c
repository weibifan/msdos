#include "lvl_pars.h"
#include "game_eng.h"
#include "world.h"
#include "view.h"
#include "log.h"
#include "dosdefs.h"

#include <stdio.h>
#include <stdlib.h>

/*
 * Runs game loop for one level.
 */
static bool play_level(struct view *view, struct world *world_init)
{
    struct world world;

    world_copy(world_init, &world);
    view_new_level(view, &world);

    while (!ge_is_game_over(&world)) {
        enum view_key key = view_get_key(view);

        switch (key) {
        case VIEW_KEY_UP:
            ge_move(GE_DIR_UP, &world);
            break;
        case VIEW_KEY_DOWN:
            ge_move(GE_DIR_DN, &world);
            break;
        case VIEW_KEY_LEFT:
            ge_move(GE_DIR_LT, &world);
            break;
        case VIEW_KEY_RIGHT:
            ge_move(GE_DIR_RT, &world);
            break;
        case VIEW_KEY_SKIP:
            return TRUE;
        case VIEW_KEY_RESTART:
            world_copy(world_init, &world);
            view_draw(view, &world);
            continue;
        case VIEW_KEY_QUIT:
            return FALSE;
        default:
            continue;
        }

        view_draw(view, &world);
    }

    return TRUE;
}

static void panic(struct view *view, char *msg)
{
    view_cleanup(view);
    printf("Error: %s -- see game.log\n", msg);
    exit(1);
}

int main(void)
{
    bool passed;
    struct world world;
    struct level_parser parser;
    struct view view;
    FILE *log_fp;

    log_fp = fopen("game.log", "w");
    if (log_fp == NULL) {
        printf("Error: could not open game.log\n");
        return 1;
    }

    log_set_fp(log_fp);

    passed = view_init(&view);
    if (!passed)
        panic(&view, "view initialization failed");

    lp_init(&parser, "levels.txt");

    passed = lp_open(&parser);
    if (!passed)
        panic(&view, "starting level parser failed");

    while (1) {
        passed = lp_next(&parser, &world);
        if (!passed)
            panic(&view, "parsing level failed");

        if (lp_stopped(&parser))
            break;

        if (!play_level(&view, &world))
            break;
    }

    passed = lp_close(&parser);
    if (!passed)
        panic(&view, "closing level parser failed");

    view_cleanup(&view);

    return 0;
}

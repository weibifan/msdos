/* === DOS Console View for Sokoban ===
 * Uses Turbo C conio.h for keyboard and screen.
 * Replaces ncurses/SDL views from original.
 */

#include "dos-view.h"
#include "world.h"
#include <conio.h>
#include <stdio.h>

#define WALL_CHAR    '#'
#define BOX_CHAR     '$'
#define WORKER_CHAR  '@'
#define DOCK_CHAR    '\xB0'   /* ░  light shade — visible dock target */
#define BOX_ON_DOCK  '*'      /* box placed on dock */
#define FLOOR_CHAR   ' '
#define WORKER_ON_DOCK '+'    /* worker standing on dock */

static void draw_tile(int row, int col, int tile)
{
    int is_worker = tile & WORLD_TILE_WORKER;
    int is_wall   = tile & WORLD_TILE_WALL;
    int is_box    = tile & WORLD_TILE_BOX;
    int is_dock   = tile & WORLD_TILE_DOCK;

    gotoxy(col + 1, row + 1);

    if (is_worker && is_dock) {
        textattr(0x0E);  /* yellow on black */
        putch(WORKER_ON_DOCK);
    } else if (is_worker) {
        textattr(0x0E);  /* yellow on black */
        putch(WORKER_CHAR);
    } else if (is_wall) {
        textattr(0x08);  /* gray on black */
        putch(WALL_CHAR);
    } else if (is_box && is_dock) {
        textattr(0x0A);  /* green on black — correct! */
        putch(BOX_ON_DOCK);
    } else if (is_box) {
        textattr(0x0C);  /* red on black */
        putch(BOX_CHAR);
    } else if (is_dock) {
        textattr(0x0B);  /* cyan on black — visible target */
        putch(DOCK_CHAR);
    } else {
        textattr(0x07);  /* gray on black */
        putch(FLOOR_CHAR);
    }
}

bool view_init(struct view *view)
{
    (void)view;
    clrscr();
    return TRUE;
}

void view_cleanup(struct view *view)
{
    (void)view;
    textattr(0x07);
    gotoxy(1, 24);
    cprintf("\nThanks for playing Sokoban!\r\n");
}

bool view_new_level(struct view *view, struct world *world)
{
    clrscr();
    gotoxy(1, 1);
    textattr(0x1F);  /* bright white on blue */
    cprintf("SOKOBAN\r\n");
    textattr(0x07);
    view_draw(view, world);
    return TRUE;
}

void view_draw(struct view *view, struct world *world)
{
    int row, col;
    unsigned nrows = world->nrows;
    unsigned ncols = world->ncols;

    if (nrows == 0) nrows = WORLD_MAX_ROWS;
    if (ncols == 0) ncols = WORLD_MAX_COLS;

    for (row = 0; row < nrows; row++) {
        for (col = 0; col < ncols; col++) {
            int tile = world_get(world, row, col);
            draw_tile(row + 2, col + 1, tile);
        }
    }

    /* Legend */
    gotoxy(1, 22);
    textattr(0x07);
    cprintf("Arrows=Move  R=Restart  S=Skip  Q=Quit\r\n");

    gotoxy(1, 23);
    textattr(0x07);
    cprintf("Legend: ");
    textattr(0x0C); cprintf("$"); textattr(0x07); cprintf("=Box  ");
    textattr(0x0B); cprintf("%c", DOCK_CHAR); textattr(0x07); cprintf("=Target  ");
    textattr(0x0A); cprintf("*"); textattr(0x07); cprintf("=Done  ");
    textattr(0x0E); cprintf("@"); textattr(0x07); cprintf("=You\r\n");
}

enum view_key view_get_key(struct view *view)
{
    int key, ext;
    (void)view;

    key = getch();
    if (key == 0 || key == 0xE0) {
        /* Extended key code */
        ext = getch();
        switch (ext) {
        case 72: return VIEW_KEY_UP;
        case 80: return VIEW_KEY_DOWN;
        case 75: return VIEW_KEY_LEFT;
        case 77: return VIEW_KEY_RIGHT;
        default: return VIEW_KEY_NONE;
        }
    }

    switch (key) {
    case 's': case 'S': return VIEW_KEY_SKIP;
    case 'r': case 'R': return VIEW_KEY_RESTART;
    case 'q': case 'Q': return VIEW_KEY_QUIT;
    default:  return VIEW_KEY_NONE;
    }
}

#ifndef VIEW_H
#define VIEW_H

#include "dos-view.h"
#include "world.h"
#include "dosdefs.h"

enum view_key {
    VIEW_KEY_UP,
    VIEW_KEY_DOWN,
    VIEW_KEY_LEFT,
    VIEW_KEY_RIGHT,
    VIEW_KEY_QUIT,
    VIEW_KEY_SKIP,
    VIEW_KEY_RESTART,
    VIEW_KEY_NONE
};

bool view_init(struct view *view);
void view_cleanup(struct view *view);
void view_draw(struct view *view, struct world *world);
enum view_key view_get_key(struct view *view);
bool view_new_level(struct view *view, struct world *world);

#endif

#ifndef WORLD_H
#define WORLD_H

#include <string.h>
#include "dosdefs.h"

#define WORLD_MAX_ROWS 32
#define WORLD_MAX_COLS 32

struct world
{
    unsigned char tiles[WORLD_MAX_ROWS][WORLD_MAX_COLS];

    unsigned nrows;
    unsigned ncols;

    unsigned worker_row;
    unsigned worker_col;
};

enum {
    WORLD_TILE_WORKER = (1 << 0),
    WORLD_TILE_WALL   = (1 << 1),
    WORLD_TILE_DOCK   = (1 << 2),
    WORLD_TILE_BOX    = (1 << 3),

    WORLD_TILE_INVALID = (1 << 4)
};

void world_init(struct world *world);
void world_dump(struct world *world);
int  world_get(struct world *world, int row, int col);
void world_move_worker(struct world *world, int to_row, int to_col);
void world_push_box(struct world *world, int from_row, int from_col, int to_row, int to_col);
void world_copy(struct world *from, struct world *to);

#endif

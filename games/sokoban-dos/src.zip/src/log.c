#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <time.h>

#include "log.h"

static struct {
  void *udata;
  log_LockFn lock;
  FILE *fp;
  int level;
  int quiet;
} L;


static const char *level_names[] = {
  "TRACE", "DEBUG", "INFO", "WARN", "ERROR", "FATAL"
};


static void lock(void)   {
  if (L.lock) {
    L.lock(L.udata, 1);
  }
}


static void unlock(void) {
  if (L.lock) {
    L.lock(L.udata, 0);
  }
}


void log_set_udata(void *udata) {
  L.udata = udata;
}


void log_set_lock(log_LockFn fn) {
  L.lock = fn;
}


void log_set_fp(FILE *fp) {
  L.fp = fp;
}


void log_set_level(int level) {
  L.level = level;
}


void log_set_quiet(int enable) {
  L.quiet = enable ? 1 : 0;
}


void log_log(int level, const char *file, int line, const char *fmt, ...) {
  time_t t;
  struct tm *lt;
  char buf[32];
  char msg[512];
  va_list args;

  if (level < L.level) {
    return;
  }

  lock();

  t = time(NULL);
  lt = localtime(&t);

  va_start(args, fmt);
  vsprintf(msg, fmt, args);
  va_end(args);

  if (!L.quiet) {
    sprintf(buf, "%02d:%02d:%02d", lt->tm_hour, lt->tm_min, lt->tm_sec);
    fprintf(stderr, "%s %-5s %s:%d: %s\n", buf, level_names[level], file, line, msg);
  }

  if (L.fp) {
    sprintf(buf, "%04d-%02d-%02d %02d:%02d:%02d",
            lt->tm_year + 1900, lt->tm_mon + 1, lt->tm_mday,
            lt->tm_hour, lt->tm_min, lt->tm_sec);
    fprintf(L.fp, "%s %-5s %s:%d: %s\n", buf, level_names[level], file, line, msg);
  }

  unlock();
}

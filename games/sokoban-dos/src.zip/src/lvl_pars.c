#include "lvl_pars.h"
#include "log.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

void lp_init(struct level_parser *parser, const char *filename)
{
    parser->filename = filename;
}

static bool lp_level_is_valid(struct level_parser *parser)
{
    if (parser->worker_count != 1)
        return false;

    if (parser->box_count != parser->dock_count)
        return false;

    return true;
}

static bool lp_parse_col(struct level_parser *parser, char ch,
                 struct world *world)
{
    char *tile;
    bool valid;

    if (parser->curr_row >= WORLD_MAX_ROWS
        || parser->curr_col >= WORLD_MAX_COLS) {
        log_log(LOG_WARN, __FILE__, __LINE__, "too large: supported level rows: %d, cols: %d",
              WORLD_MAX_ROWS, WORLD_MAX_COLS);
        return false;
    }

    tile = &world->tiles[parser->curr_row][parser->curr_col];
    valid = false;

    if (ch == '#') {
        *tile |= WORLD_TILE_WALL;
        valid = true;
    }

    if (ch == '@' || ch == '+') {
        *tile |= WORLD_TILE_WORKER;
        parser->worker_count++;
        world->worker_row = parser->curr_row;
        world->worker_col = parser->curr_col;
        valid = true;
    }

    if (ch == '.' || ch == '*' || ch == '+') {
        *tile |= WORLD_TILE_DOCK;
        parser->dock_count++;
        valid = true;
    }

    if (ch == '$' || ch == '*') {
        *tile |= WORLD_TILE_BOX;
        parser->box_count++;
        valid = true;
    }

    if (ch == ' ')
        valid = true;

    if (!valid) {
        log_log(LOG_WARN, __FILE__, __LINE__, "invalid char '%c' in level", ch);
        return false;
    }

    return true;
}

static int is_end_of_level(char *line)
{
    return line[0] == '\n';
}

static int is_end_of_row(char ch)
{
    return ch == '\n';
}

static int is_comment(char *line)
{
    return line[0] == ';';
}

static bool lp_parse_row(struct level_parser *parser, char *line,
                 struct world *world)
{
    int i;

    for (i = 0; line[i] != '\0'; i++) {
        bool passed;

        if (is_end_of_row(line[i])) {
            if (parser->curr_col > world->ncols)
                world->ncols = parser->curr_col;

            parser->curr_col = 0;
            parser->curr_row++;
            return true;
        }

        passed = lp_parse_col(parser, line[i], world);
        if (!passed)
            return passed;

        parser->curr_col++;
    }

    return true;
}

bool lp_open(struct level_parser *parser)
{
    parser->fp = fopen(parser->filename, "r");
    if (parser->fp == NULL) {
        log_log(LOG_ERROR, __FILE__, __LINE__, "error opening levels file '%s'", parser->filename);
        return false;
    }

    parser->stopped = false;
    return true;
}

static void lp_init_level(struct level_parser *parser, struct world *world)
{
    world_init(world);

    parser->curr_row = 0;
    parser->curr_col = 0;
    parser->done = false;
    parser->parse_error = false;

    parser->worker_count = 0;
    parser->box_count = 0;
    parser->dock_count = 0;
}

static bool lp_do_line(struct level_parser *parser, char *line,
                   struct world *world)
{
    bool passed;

    if (line == NULL) {
        if (ferror(parser->fp)) {
            log_log(LOG_ERROR, __FILE__, __LINE__, "error reading from file");
            return false;
        }

        if (parser->curr_row != 0) {
            log_log(LOG_ERROR, __FILE__, __LINE__, "unexpected EOF, parsing file");
            return false;
        }

        parser->stopped = true;
        return true;
    }

    if (line[strlen(line) - 1] != '\n') {
        log_log(LOG_WARN, __FILE__, __LINE__, "line too long in level");
        return false;
    }

    if (is_comment(line))
        return true;

    if (is_end_of_level(line)) {
        world->nrows = parser->curr_row;
        parser->done = true;
        return true;
    }

    passed = lp_parse_row(parser, line, world);
    if (!passed) {
        parser->parse_error = true;
        return true;
    }

    return true;
}

bool lp_next(struct level_parser *parser, struct world *world)
{
    char line[64];
    char *retp;
    bool passed;

    lp_init_level(parser, world);

    while (1) {
        retp = fgets(line, sizeof(line), parser->fp);
        passed = lp_do_line(parser, retp, world);
        if (!passed)
            return passed;

        if (parser->stopped)
            return true;

        if (parser->done) {
            if (parser->parse_error || !lp_level_is_valid(parser)) {
                lp_init_level(parser, world);
                continue;
            }
            return true;
        }
    }

    return true;
}

bool lp_stopped(struct level_parser *parser)
{
    return parser->stopped;
}

bool lp_close(struct level_parser *parser)
{
    int ret;

    ret = fclose(parser->fp);
    if (ret == -1) {
        log_log(LOG_ERROR, __FILE__, __LINE__, "error closing levels file '%s'", parser->filename);
        return false;
    }

    return true;
}

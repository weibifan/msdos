#ifndef GAME_ENGINE_H
#define GAME_ENGINE_H

#include "world.h"
#include "dosdefs.h"

enum ge_dir {
    GE_DIR_UP,
    GE_DIR_DN,
    GE_DIR_LT,
    GE_DIR_RT,
};

void ge_move(enum ge_dir dir, struct world *world);
bool ge_is_game_over(struct world *world);

#endif

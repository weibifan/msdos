#ifndef DOS_VIEW_H
#define DOS_VIEW_H

#include "view.h"
#include "dosdefs.h"

struct view {
    int dummy;
};

#endif

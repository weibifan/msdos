/*
  Program: Mine Mayhem
  File:    options.h
  Date:    July, 1996 to February,   1997,    version 1.00
	   26 October to 3 December,	      version 2.00
	   8 December to 4 January,  2001,    version 2.10
	   15 January,			      version 2.11
	   18 September to 16 December, 2006, version 2.90

  Definitions for the configuration dialog box.

  Freeware, Copyright 2006 Jason Hood.
*/

#ifndef _options_h
#define _options_h

#include <tws/tabwin.h>
#include <tws/checkbox.h>
#include <tws/button.h>
#include "radiogrp.h"


extern int Start;			// Starting condition:
#define NONE		0		//   first may be a mine
#define DISPLACE	1		//   a "guess" will never be a mine
#define BLANK		2		//   first will have no mines
#define PERIMETER	3		//   entire perimeter is opened first

extern int Finish;			// Finishing condition (bit-masked):
#define ALL_OPENED	1		//   open everything not having a mine
#define ALL_MARKED	2		//   mark everything having a mine

extern int Counter;			// Mine counter:
#define NORMAL		0		//   doesn't change
#define REMOVE		1		//   blanked when same as flags
#define UPDATE		2		//   changes according to flags

extern int Hints;
//#define NONE		0
#define CLUES		1		// Number of tiles to open/mark
#define WHERE		2		// Which tiles can be opened/marked
#define WHAT		3		// Distinguish between open and mark

extern bool isLogical,			// No guesswork required
	    isMarks,			// Use mark counter instead of flag
	    isTracked,			// Keep opening/marking as mouse moves
	    isWrap,			// Clear game's edges fold together
	    isAutoClear,		// Clear-around after opening
	    isAutoMark, 		// Mark after opening
	    isAutoOpen; 		// Open after marking


class OptionDlg : public TabWin
{
public:
  OptionDlg();
  ~OptionDlg();

  void Run();

protected:
  void PaintWindow(int x1, int y1, int x2, int y2);

  void cmOK();
  void cmCancel();
  void cmStart(int);
  void cmFinish();
  void cmCounter(int);
  void cmGeneral();
  void cmClear();
  void cmWrap();

  DECLARE_RESPONSE_TABLE;

  RadioGroup *start;
  CheckBox   *finishopen, *finishmark;
  RadioGroup *count;
  CheckBox   *logical, *marks, *track, *wrap;
  CheckBox   *autoclear, *automark, *autoopen;
  TextButton *OK, *Cancel;
  int isOK;
  int ix, iy;
};

#endif

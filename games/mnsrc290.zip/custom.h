/*
  Program: Mine Mayhem
  File:    custom.h
  Date:    July, 1996 to February,   1997,    version 1.00
	   26 October to 3 December,	      version 2.00
	   8 December to 4 January,  2001,    version 2.10
	   15 January,			      version 2.11
	   18 September to 16 December, 2006, version 2.90

  Definitions for the custom layout dialog box and popup menu.

  Freeware, Copyright 2006 Jason Hood.
*/

#ifndef _custom_h
#define _custom_h

#include <tws/tabwin.h>
#include <tws/static.h>
#include <tws/button.h>
#include <tws/menu.h>
#include "layout.h"
#include "spin.h"


class CustomDlg : public TabWin
{
public:
  CustomDlg();
  ~CustomDlg();

  bool Run();                           // true for OK, false for Cancel

protected:
  void PaintWindow(int x1, int y1, int x2, int y2);

  void SaveState();
  void SetState(cLayout& layout);

  void cmStr();
  void cmBeg();
  void cmInt();
  void cmExp();
  void cmRan();
  void cmRes();

  void cmSav();
  void cmDel();

  void cmChange();

  void cmOK();
  void cmCancel();

  DECLARE_RESPONSE_TABLE;

  Spin *WidthEdit, *HeightEdit, *MineEdit;
  StaticText *Diff;
  TextButton *Str, *Beg, *Int, *Exp, *Ran, *Res,
	     *Sav, *Del,
             *OK, *Cancel;
  bool isOK;
  Layout save;
};


const unsigned CustomLen = 18 + 1;	// "ww x hh, ddd Mines\0"


struct CustomPopupRes
{
  CustomPopupRes() : number(0) { }
  ~CustomPopupRes();

  int number;				// The number of custom games stored
  Layout* layout;			// The layout of each
  PopupMenuRes* menu;			// The menu data

  int  Find(cLayout& lo);		// Find a game
  bool Insert(cLayout& lo);		// Add a new game
  void Delete(cLayout& lo);		// Remove a game
};


class CustomPopupMenu : public AutoPopupMenu
{
public:
  CustomPopupMenu(Window* parent, const CustomPopupRes& custom, int x, int y);

  bool Run();

protected:
  void cmSelection(unsigned game);

  void keyESC(int);                             // Press Escape or click
  void LButtonDown(int x, int y, int);          // outside the menu to cancel

  DECLARE_RESPONSE_TABLE;

  const CustomPopupRes* popup;
  bool cancelled;
};

#endif

/*
 * puzzles.h: header file for my (Simon Tatham) puzzle collection
 *
 * Jason Hood: keep only what is necessary for the Minesweeper solver.
 */


#define lenof(array) ( sizeof(array) / sizeof(*(array)) )

/*
 * malloc.c
 */

void *smalloc(size_t size);
void *srealloc(void *p, size_t size);
void sfree(void *p);

#define snew(type) \
    ( (type *) smalloc (sizeof (type)) )
#define snewn(number, type) \
    ( (type *) smalloc ((number) * sizeof (type)) )
#define sresize(array, number, type) \
    ( (type *) srealloc ((array), (number) * sizeof (type)) )


#define random_upto(limit) (unsigned long)(random() % (limit))

/*
  Program: Mine Mayhem
  File:    menuicon.h
  Date:    July, 1996 to February,   1997,    version 1.00
	   26 October to 3 December,	      version 2.00
	   8 December to 4 January,  2001,    version 2.10
	   15 January,			      version 2.11
	   18 September to 16 December, 2006, version 2.90

  Definitions for the icon buttons on the menu.

  Freeware, Copyright 2006 Jason Hood.
*/

#ifndef _menuicon_h
#define _menuicon_h

#include <graphics.h>

#define MENUICONW 15
#define MENUICONH 15

enum
{
  MENUSQUARES,
  MENUHEXAGONS,
  MENUHEXAGONAL,
  MENUCLEAR,
  MENUPERIMETER,
  MENUWRAP,
  MENUCROSS,
  MENUNONE,
  MENUMARK,
  MENUOPEN,
  MENUBOTH,
  MENUICONS
};

extern ViewBuffer* MenuIcon[MENUICONS];

extern BYTE MenuIconBuffer[MENUICONS][MENUICONW*MENUICONH];

#endif

/*
  Program: Mine Mayhem
  File:    tiles.h
  Date:    July, 1996 to February,   1997,    version 1.00
	   26 October to 3 December,	      version 2.00
	   8 December to 4 January,  2001,    version 2.10
	   15 January,			      version 2.11
	   18 September to 16 December, 2006, version 2.90

  Definitions for the tiles (squares and hexagons) on the board.

  Freeware, Copyright 2006 Jason Hood.
*/

#ifndef _tiles_h
#define _tiles_h

#include <graphics.h>

#define SQUAREW   16
#define SQUAREH   16
#define HEXAGONW  16
#define HEXAGONH  18
#define HEXAGONR  14			// Each row is this far apart
#define HEXAGOND   4			// Difference of the two above values
#define OTILEW	  10
#define OTILEH	  10

enum
{
  bufUNOPENED,
  bufOPENED,
  bufDEADMINE,
  bufMARKBG,				// background of counted mark
  bufMARKXBG,				// background of wrong counted mark
  bufMARKUBG,				// background of unknown counted mark
  TILES,
  bufMINE = TILES,
  bufWRONGMINE,
  SQRTILES,
  HEXOUTLINE1 = TILES,
  HEXOUTLINE2,
  HEXTILES,

  bufMARKED = 0,
  /* 1 to 9 */
  bufHINT   = 10,
  bufHINTMARK,
  bufHINTOPEN,
  bufHINTMARKX, 			// Marked a wrong tile
  bufHINTMARKU, 			// Marked an unknown tile
  OTILES
};

extern ViewBuffer * Square[SQRTILES],
		  *Hexagon[HEXTILES],
		  *Overlay[OTILES];

extern BYTE  SquareBuffer[SQRTILES][SQUAREW*SQUAREH],
	    HexagonBuffer[HEXTILES][HEXAGONW*HEXAGONH],
	    OverlayBuffer[OTILES][OTILEW*OTILEH];

extern BYTE HexMask[HEXAGOND][HEXAGONW];

#endif

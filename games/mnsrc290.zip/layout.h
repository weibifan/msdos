/*
  Program: Mine Mayhem
  File:    layout.h
  Date:    26 October to 3 December, 1997,    version 2.00
	   8 December to 4 January,  2001,    version 2.10
	   15 January,			      version 2.11
	   18 September to 16 December, 2006, version 2.90

  The dimensions of the minefield.

  Freeware, Copyright 2006 Jason Hood.
*/

#ifndef _layout_h
#define _layout_h


struct Coord				// Something different to Point :)
{
  int x, y;				// Or col & row, width & height

  Coord(int c = 0, int r = 0) : x(c), y(r) {}

  int operator==(const Coord& coord) const
  {
    return (x == coord.x && y == coord.y);
  }
};

typedef const Coord cCoord;


struct Layout
{
  Coord dim;
  int mines;

  Layout() {}
  Layout(cCoord& d,    int m) : dim(d),    mines(m) {}
  Layout(int w, int h, int m) : dim(w, h), mines(m) {}

  double diff() const;
  double speed(double time) const;
  double rating(int bbbv) const;
  const char* str() const;

  int operator==(const Layout& layout) const
  {
    return (dim == layout.dim && mines == layout.mines);
  }
};

typedef const Layout cLayout;

#endif

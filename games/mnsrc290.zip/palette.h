#ifndef _palette_h
#define _palette_h

#include <tws/window.h>
#include <tws/static.h>

class PaletteWindow : public Window
{
public:

  PaletteWindow(int x, int y);
  ~PaletteWindow() { delete Colour; }

protected:

  void PaintWindow(int x1, int y1, int x2, int y2);
  void cmSysBox() { ws.StopRunningEvents(); }
  void MouseMove(int x, int y, int, int);
  void MoveOutside(int, int, int, int) { Colour->SetText(""); }

  DECLARE_RESPONSE_TABLE;

  StaticText* Colour;
};

#endif

/*
  Program: Mine Mayhem
  File:    sound.h
  Date:    26 October to 3 December,	      version 2.00
	   8 December to 4 January,  2001,    version 2.10
	   15 January,			      version 2.11
	   18 September to 16 December, 2006, version 2.90

  Definitions for the sound configuration dialog box.

  Freeware, Copyright 2006 Jason Hood.
*/

#ifndef _sound_h
#define _sound_h

#include <tws/sb.h>
#include <tws/tabwin.h>
#include <tws/checkbox.h>
#include <tws/button.h>


extern SOUND_SAMPLE *open_snd, *mark_snd, *win_snd, *die_snd;
extern bool isSound, SwapStereo, OpenSnd, MarkSnd, WinSnd, DieSnd;


class SoundDlg : public TabWin
{
public:
  SoundDlg();
  ~SoundDlg();

  void Run();

protected:
  void PaintWindow(int x1, int y1, int x2, int y2);

  void cmOK();
  void cmCancel();

  DECLARE_RESPONSE_TABLE;

  CheckBox   *sound, *swap,
	     *open,  *mark,
	     *win,   *die;
  TextButton *OK,    *Cancel;
  int isOK;
};

#endif

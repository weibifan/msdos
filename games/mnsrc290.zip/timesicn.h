/*
  Program: Mine Mayhem
  File:    timesicn.h
  Date:    18 September to 16 December, 2006, version 2.90

  Definitions for the icons on the times (and options) display.

  Freeware, Copyright 2006 Jason Hood.
*/

#ifndef _timesicn_h
#define _timesicn_h

#include <graphics.h>

#define TIMESICONW 12
#define TIMESICONH 12

extern const BYTE TimesIconBuffer[][TIMESICONW*TIMESICONH];

extern ViewBuffer *TimesIconStart[3],
		  *TimesIconFinish[4],
		  *TimesIconCounter[3],
		  *TimesIconGeneral[2][2],
		  *TimesIconClear[2],
		  *TimesIconWrap;

#endif

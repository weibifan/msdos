/*
  RadioGroup: alternative to RadioButtonContainer.

  Jason Hood, 10 to 14 December, 2000.

  This class is virtually identical to RadioButtonContainer.
  The differences are:
    * an event is generated when a button is (re)selected;
    * an extra line between the frame and first item;
    * up and down will wrap.
*/

#ifndef _RadioGroup_H
#define _RadioGroup_H

#include <tws/radio.h>


// Execute function() when ID is selected.
#define E_RADIO(ID, function) \
  if (ev->Type == W_NOTIFY && ev->p1 == ID && ev->p2 == 2002) \
  { \
    function(); \
    return true; \
  }

// Execute function(int) when an ID within a range of IDs is selected.
#define E_RADIO_GROUP(IDmin, IDmax, function) \
  if (ev->Type == W_NOTIFY && ev->p1 >= IDmin \
			   && ev->p1 <= IDmax && ev->p2 == 2002) \
  { \
    function(ev->p1); \
    return true; \
  }


class RadioGroup : public Window
{
public:
  RadioGroup(Window *parent, int x1, int y1, int x2, int y2,
			     int type = RADIO_TYPE_NONE);
  ~RadioGroup();

  void AddButton(char *text, ControlID ID);
  void SelectButton(ControlID ID);
  ControlID GetSelectedButton();

protected:
  void PaintWindow(int, int, int, int);
  void Focus();
  void UnFocus();
  void KeyUp(int);
  void KeyDown(int);
  void KeyEnter(int);

  DECLARE_RESPONSE_TABLE;

  int n,				// Number of buttons in group
      pos,				// Number of selected button
      type;				// Type of frame
  int buttons;				// Number of buttons allocated
  RadioButton** button; 		// Array of button pointers
};

#endif

/*
  Program: Mine Mayhem
  File:    mainmenu.h
  Date:    July, 1996 to February,   1997,    version 1.00
	   26 October to 3 December,	      version 2.00
	   8 December to 4 January,  2001,    version 2.10
	   15 January,			      version 2.11
	   18 September to 16 December, 2006, version 2.90

  Definitions for the main menu.

  Freeware, Copyright 2006 Jason Hood.
*/

#ifndef _mainmenu_h
#define _mainmenu_h

#include <tws/menu.h>
#include <tws/static.h>
#include <tws/button.h>
#include <dos.h>


class MainMenu : public AutoMenu
{
public:
  MainMenu(Window* parent, int x, int y, int w);

protected:
  void cmGameStyle(int style);
  void cmGameType(int type);
  void cmGameNew(int level);
  void cmGameExit();

  void cmOptionsTimes();
  void cmOptions3BVps();
  void cmOptionsStats();
  void cmOptionsConfig();
  void cmOptionsSound();

  void cmHelpContents();
  void cmHelpAbout();

  DECLARE_RESPONSE_TABLE;
};


class MainMenuWindow : public Window
{
  friend class MainMenu;

public:
  MainMenuWindow();
  ~MainMenuWindow();

  void cmGame(bool UpdateOnly = false);
  void cmHints(int hint);
protected:
  void cmStyle();
  void cmAuto(bool UpdateOnly = false);
  void Timer();                         // Display the current time

  DECLARE_RESPONSE_TABLE;

  MainMenu   *menu;
  IconButton *StyleButton, *GameButton, *AutoButton;
  StaticText *tym;
  struct time old_time;
};

extern MainMenuWindow* Main;

#endif

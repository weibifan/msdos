/*
  Program: Mine Mayhem
  File:    faces.h
  Date:    July, 1996 to February,   1997,    version 1.00
	   26 October to 3 December,	      version 2.00
	   8 December to 4 January,  2001,    version 2.10
	   15 January,			      version 2.11
	   18 September to 16 December, 2006, version 2.90

  Definitions for the face (smiley) button.

  Freeware, Copyright 2006 Jason Hood.
*/

#ifndef _faces_h
#define _faces_h

#include <graphics.h>

#define FACEICONW  24
#define FACEICONH  24

enum
{
  FACEPUSHED,
  FACECOOL,
  FACEDEAD,
  FACESLEEPY,
  FACESMILEY,
  FACEBLAND,
  FACEICONS
};

extern ViewBuffer* FaceIcon[FACEICONS];

extern BYTE FaceIconBuffer[FACEICONS][FACEICONW*FACEICONH];

#endif

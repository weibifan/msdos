/*
  Program: Mine Mayhem
  File:    mine.h
  Date:    July, 1996 to February,   1997,    version 1.00
	   26 October to 3 December,	      version 2.00
	   8 December to 4 January,  2001,    version 2.10
	   15 January,			      version 2.11
	   18 September to 16 December, 2006, version 2.90

  Definitions for the minefield.

  Freeware, Copyright 2001 Jason Hood.
*/

#ifndef _mine_h
#define _mine_h

// Are we clearing or crossing the field?
extern int Game;
enum { CLEAR, CROSS, NoGameTypes };

// Is it a square-tiled, hexagon-tiled, or hexagonal minefield?
extern int GameStyle;
enum { SQUARES, HEXAGONS, HEXAGONAL, NoGameStyles };

// The levels - 2 to 10 are the appropriate random games.
enum { BEGINNER = 11, INTERMEDIATE, EXPERT, CUSTOM };

// The game progress.
enum { NOT_PLAYING, PLAYING, FINISHED };

// Various screen dimensions.
extern int max_width, max_height, stath;

// The highest hints used.
extern int hintsused;

#endif

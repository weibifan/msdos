/*
  Program: Mine Mayhem
  File:    board.h
  Date:    July, 1996 to February,   1997,    version 1.00
	   26 October to 3 December,	      version 2.00
	   8 December to 4 January,  2001,    version 2.10
	   15 January,			      version 2.11
	   18 September to 16 December, 2006, version 2.90

  Definitions for the board window.

  Freeware, Copyright 2006 Jason Hood.
*/

#ifndef _board_h
#define _board_h

#include <tws/button.h>
#include "layout.h"
#include "digits.h"
#include <time.h>

class Tile;


// This is queued when the right mouse button is pressed on the "face" button
#define E_BUTTONR(ID, function) \
  if (ev->Type == W_NOTIFY && ev->p1 == ID && ev->p2 == 1003) \
  { \
    function(); \
    return true; \
  }


// The "face" button in the middle of the board.
class FaceButton : public IconButton
{
  friend class BoardWindow;

public:
  FaceButton(Window* parent, ControlID ID, int x, int y, int icon);

  void ChangeIcon(int NewIcon);
  void Display(int Icon);

protected:
  void PaintWindow(int x1, int y1, int x2, int y2);
  void RButtonDown(int, int, int);

  DECLARE_RESPONSE_TABLE;

  int curicon;
};


class BoardWindow : public Window
{
public:
  BoardWindow();
  ~BoardWindow();

  void NewGame(cCoord& dim, int mines, int spaces);
  void StartTiming();
  int  GameOver(bool dead);
  void DisplayFace();
  void DisplayProgress(int mines, int spaces);
  void DisplayTile(int x, int y, int w, int h, ViewBuffer* tile);
  void Display();
  void DisplayClues(int clues);
  bool Paused() const { return isPaused; }

protected:
  void DisplayTime(bool full = false);	// Display milliseconds if full is true
  void Display(int num, int x, int y,   // Display num using LED digits
	       ViewBuffer* bmp[] = Digit, bool zeros = false);
  void DisplayStats(bool after);

  void Resize(int width, int height);
  void PaintWindow(int x1, int y1, int x2, int y2);

  void cmNewGame();			// The smiley has been pressed

  void ButtonDown(int x, int y, int b);
  void ButtonUp(int b); 		// Remove the highlight

  void MouseMove(int x, int y, int, int but_stat);

  void Timer();                         // Update the time taken
  void cmPause(int = 0);		// Right click the smiley or use
					// the P key (hence the parameter)
  void cmDump(int = 0); 		// Save the board as a bitmap

  DECLARE_RESPONSE_TABLE;

  FaceButton* Face;			// Why didn't I call it smiley?

  int  ox, oy, timex, spacesx;		// Offsets for display
  int  rx1, ry1, rx2, ry2;		// Rectangle to refresh

  int  secs, mils;			// Time taken
  uclock_t startmils, pausemils;	// Time calibration
  int  oldsecs;
  bool progress;			// No progress display once game is won
  int  oldmines, oldspaces, oldclues;
  int  clicks[2], goodclicks[2];
  DWORD ticks;

  Layout olddim;			// Previous game's dimensions
  Tile*  old_t; 			// Previous tile for tracking
  int	 butt;				// Button being tracked

  bool isPaused;			// The game is paused
  ViewBuffer* gridsave; 		// Copy of the grid prior to pause
};

extern BoardWindow* Board;

#endif

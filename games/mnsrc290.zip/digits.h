/*
  Program: Mine Mayhem
  File:    digits.h
  Date:    July, 1996 to February,   1997,    version 1.00
	   26 October to 3 December,	      version 2.00
	   8 December to 4 January,  2001,    version 2.10
	   15 January,			      version 2.11
	   18 September to 16 December, 2006, version 2.90

  Definitions for the LED digits.

  Freeware, Copyright 2006 Jason Hood.
*/

#ifndef _digits_h
#define _digits_h

#include <graphics.h>

#define DIGITW	    13
#define DIGITH	    23
#define SMALLDIGITW  9
#define SMALLDIGITH 16

enum
{
  /* 0 to 9 */
  MINUS = 10,
  EMPTY,
  DIGITS
};

extern ViewBuffer *Digit[DIGITS],
		  *SmallDigit[DIGITS];

extern BYTE DigitBuffer[DIGITS][DIGITW*DIGITH],
	    SmallDigitBuffer[DIGITS][SMALLDIGITW*SMALLDIGITH];

#endif
